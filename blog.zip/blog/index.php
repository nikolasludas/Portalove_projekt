<?php
    require "config/DB.php";

    $query = "SELECT * FROM posts ORDER BY created_on DESC";
    $result = mysqli_query($conn, $query);
    $posts = mysqli_fetch_all($result, MYSQLI_ASSOC);

    mysqli_free_result($result);
    mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once("header.php"); ?>
    <title>Tech blog</title>

    <style>
        input[type=button] {
            float: right;
            position: relative;
            right: 30px;
            background-color: white;
            border-style: solid;
            border-color: #122b40;
            color: #122b40;
            padding: 16px 90px;
            text-decoration: none;
            margin: 4px 2px;
            cursor: pointer;
            font-family: 'Open Sans','Helvetica Neue',Helvetica,Arial,sans-serif;
        }
        input[type=button]:hover
        {
            background-color: #122b40;
            color:white;
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <?php include_once("menu.php"); ?>

    <!-- Page Header -->
    <header class="intro-header" style="background-image: url('img/homeBG.jpg')">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                    <div class="site-heading">
                        <h1>Tech Blog</h1>
                        <hr class="small">
                        <span class="subheading">Technical…Practical…Theoretically Interesting</span>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <input type="button" class="button" onclick="location.href='addpost.php';" value="Add Post" />

    <?php foreach ($posts as $blog): ?>
        <div style="margin-bottom: 60px"class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                    <div class="post-preview">
    				    <img src="<?php echo $blog["image"] ?>" alt="<?php echo $blog["title"] ?>" width="100%" height="200">

                        <h2 style="display: inline-block" href="post.php"class="post-title">
                                <?php echo $blog["title"] ?>
                        </h2>
                        <p style="font-size: 22px; margin-top: 30px; margin-bottom: 10px"><?php echo substr($blog["text"], 0, 100) ?>...</p>
                        <p class="post-meta">Posted by <?php echo $blog["author"] ?> on <?php echo $blog["created_on"] ?></p>
                        <a style="float: right;margin-top:-30px" href="post.php?id=<?php echo $blog["id"] ?>">Read more</a>
                    </div>
                    <hr>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
    <hr>

    <!-- Footer -->
    <?php include_once("footer.php"); ?>
</body>
</html>
