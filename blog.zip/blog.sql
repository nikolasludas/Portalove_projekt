-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2020 at 01:31 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `image` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `author`, `text`, `created_on`, `image`) VALUES
(8, 'Social Media Companies Top Data Grabber List', 'John P. Mello Jr..', '\"Ads are how Facebook makes the most of their money -- around [US]$16.6 billion to be precise, based on their 2018 reports -- so the more they know about you, the more they can sell on,\" explained Clario Content Manager Mary Atamaniuk, in a company blog.\"\r\n\"As well as the usual, such as your name, location, email address and date of birth, they also collect a whole load of things you might not be aware you gave away,\" she added.\r\n\r\nIn fact, of the 32 items of personal information identified as collectible by Clario, only seven arent grabbed by Facebook -- height, weight, mothers maiden name, bank account details, salary, country of birth, allergies/intolerances and health and lifestyle information.', '2020-11-01 19:08:44', 'https://www.technewsworld.com/article_images/story_graphics_xlarge/xl-2018-social-media-users-1.jpg'),
(83, 'A Momentous Week for 4 Tech Vendors', 'Rob Enderle', 'I\'d typically argue that having a significant event or announcement anywhere near an election is foolish. Well, four vendors decided to prove me wrong by having events and making announcements that have a material impact that, at times, goes well beyond the technology market and the U.S.\r\n\r\nEven though this was unintentional, each vendor\'s announcement appeared designed to cut through the noise, and some could directly impact future elections.\r\n\r\nLet\'s talk about how Cisco, Lenovo, Microsoft, and Qualcomm disrupted the world last week, and we\'ll close with my new favorite digital assistant, the new Amazon Echo 4th Generation, which may be one of the best holiday gifts under $100.\r\n\r\nCisco\r\nCisco had its partner event last week, and while much of that event focused on Cisco\'s channel efforts, there was a ton of additional content. Due to the election, there were two things they announced that particularly caught my attention. Those were Connected Justice Solution for Courts and Webex Legislate.', '2020-11-02 17:59:49', 'https://www.technewsworld.com/article_images/story_graphics_xlarge/xl-2016-innovation-1.jpg'),
(84, 'AdGuard Home: Another Brick in the Ad-Blocking Wall', 'Jonathan Terrasi', 'Canonical\'s AdGuard Home Ubuntu Appliance is a new addition to the ranks of its appliances. With this offering, users can quickly implement a ready-made solution for blocking bothersome content at the network level on a home network. Doing so involves no more than downloading, installing, and booting the newly released lean Ubuntu image with the AdGuard Home service pre-installed and pre-configured.\r\n\r\nA better way to phrase this development, though, is that Ubuntu is building something, and it just laid another sturdy brick. The edifice may be humble (and little more than a foundation) now, but it holds more potential than users may at first realize.\r\n\r\nMiniaturized Ubuntu\r\nAt the core of the emerging foundation that is Ubuntu Appliances is the aptly named Ubuntu Core, a slimmed-down Ubuntu operating system crafted with the IoT use case in mind. What distinguishes Ubuntu Core, which users can run as a standalone, and Ubuntu Appliances, is that each appliance comes preloaded with a featured service, and all the necessary programs are installed and managed via the Snaps containerized installation mechanism.', '2020-11-02 18:04:25', 'https://www.technewsworld.com/article_images/story_graphics_xlarge/xl-2020-ubuntu-adguard-1.jpg'),
(85, 'A Vision of the Future From Dell World', 'Rob Enderle', 'Dell World was last week, and it sure was different this year because it was done virtually. One of the most interesting parts of Dell World is the session on the future. In past years they surfaced the coming of the Fourth Industrial Revolution and the coming wave of robotics.\r\n\r\nThis year, they spoke on a new branch of engineering that is solely AI-focused, the blended technology revolution surrounding food production, how AIs were intentionally corrupted, and how music, math, and the Internet create new entertainment types.\r\n\r\nLet\'s talk about that this week, and I\'ll close with a product of the week that isn\'t quite a product yet -- a technology that will transform your earbuds into smart earbuds and potentially give you superpowers (well, one superpower anyway).\r\n\r\nGenevieve Bell: The 3A Institute on AI\r\nGenevieve Bell is one of my favorite people and an Intel Senior Fellow working out of their research organization. She opened this segment on the future talking about a new effort she spearheads that pulls together many very different skills and people to create a new engineering-centric branch solely focused on artificial intelligence. I say engineering-centric because the folks involved come from a broad spectrum of backgrounds and skills that include engineers as well as anthropologists, scientists, policy experts, and even musicians.', '2020-11-02 18:06:37', 'https://www.technewsworld.com/article_images/story_graphics_xlarge/xl-2015-artificial-intelligence-1.jpg'),
(86, 'The Unix Way', 'Jonathan Terrasi', 'It probably shouldn\'t, but it routinely astonishes me how much we live on the Web. Even I find myself going entire boots without using anything but the Web browser. With such an emphasis on Web-based services, one can forget to appreciate the humble operating system.\r\n\r\nThat said, we neglect our OS at the risk of radically underutilizing the incredible tools that it enables our device to be.\r\n\r\nMost of us only come into contact with one, or possibly both, of two families of operating systems: \"House Windows\" and \"House Practically Everything Else.\" The latter is more commonly known as Unix.\r\n\r\nWindows has made great strides in usability and security, but to me it can never come close to Unix and its progeny. Though more than 50 years old, Unix has a simplicity, elegance, and versatility that is unrivalled in any other breed of OS.\r\n\r\nThis column is my exegesis of the Unix elements I personally find most significant. Doctors of computer science will concede the immense difficulty of encapsulating just what makes Unix special. So I, as decidedly less learned, will certainly not be able to come close. My hope, though, is that expressing my admiration for Unix might spark your own.', '2020-11-02 18:07:41', 'https://www.technewsworld.com/article_images/story_graphics_xlarge/xl-2017-linux-terminal-1.jpg'),
(97, 'Title', 'Author author', 'Text Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text TextText Text Text', '2020-11-04 16:03:11', 'https://wallpaperaccess.com/full/2454628.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
