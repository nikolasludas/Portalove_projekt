<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once("header.php"); ?>
    <title>About page</title>
</head>

<body>
    <!-- Navigation -->
    <?php include_once("menu.php"); ?>

    <!-- Page Header -->
    <!-- Set your background image for this header on the line below. -->
    <header class="intro-header" style="background-image: url('img/about-bg.jpg')">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                    <div class="page-heading">
                        <h1>About us</h1>
                        <hr class="small">
                        <span class="subheading">This is what we do.</span>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                <p>Tech blog is one of the most popular e-business and technology news publishers in the United States. Our network of business and technology news publications attracts a targeted audience of buyers and decision-makers who need timely industry news and reliable analysis.</p>
                <p>The network currently includes several e-business and technology news sites: the E-Commerce Times®, TechNewsWorld™, CRM Buyer™ and LinuxInsider™. Tech Blog also publishes the E-Commerce Minute™ and the Tech News Flash™ daily newsletters and the ECT News Network Weekly Newsletter™.</p>
                <p>These publications are some of the most respected and widely-read business and technology news sites of the Internet age. Tech Blog features an award-winning team of journalists who produce daily news and industry analysis.</p>
                <p>Daily readers of Tech Blog include a "Who's Who" of the Internet industry. Most are IT professionals, businesspeople and corporate decision-makers, e-commerce providers, digital marketers and web developers, industry analysts, investors, consultants and others who need to stay informed about e-business and technology trends.</p>
            </div>
        </div>
    </div>

    <hr>

    <!-- Footer -->
    <?php include_once("footer.php"); ?>

</body>
</html>
