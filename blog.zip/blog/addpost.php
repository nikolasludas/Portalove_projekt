<?php
    require "config/DB.php";

    if(isset($_POST["submit"])){

        $title = $_POST["title"];
        $author = $_POST["author"];
        $text = $_POST["text"];
        $image = $_POST["image"];

        $query = "INSERT INTO posts (title,author,text,image) VALUES ('$title','$author','$text','$image')";

        if(mysqli_query($conn,$query)){
            header("Location:".ROOT_URL."");
        } else {
            echo "ERROR: ".mysqli_error($conn);
        }
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once("header.php"); ?>
    <title>Add post</title>

    <style>
        form{
            width: 50%;
            margin: 100px auto;
            display: flex;
            flex-direction: column;
        }

        form input{
            height: 60px;
            margin: 15px 0;
        }

        textarea{
            margin: 15px 0;
        }

        input[type="submit"]{
            background-color: white;
            border-style: solid;
            border-color: #122b40;
            color: #122b40;
            padding: 16px 90px;
            text-decoration: none;
            margin: 4px 2px;
            cursor: pointer;
            font-family: 'Open Sans','Helvetica Neue',Helvetica,Arial,sans-serif;
        }

        input[type="submit"]:hover{
            background-color: #122b40;
            color:white;
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <?php include_once("menu.php"); ?>

    <!-- Page Header -->
    <header class="intro-header" style="background-image: url('img/add-edit.png')">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                    <div class="site-heading">
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="POST">
        <label>Paste link to image</label>
        <input type="text" name="image">

        <label>Title</label>
        <input type="text" name="title">

        <label>Author</label>
        <input type="text" name="author">

        <label>Text</label>
        <textarea name="text" id="" cols="30" rows="10"></textarea>

        <input type="submit" value="Submit" name="submit">
    </form>

    <hr>
    <!-- Footer -->
    <?php include_once("footer.php"); ?>
</body>
</html>
