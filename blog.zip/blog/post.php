<?php
    require "config/DB.php";

    if(isset($_POST["delete"])) {
        $delete_id = $_POST["delete_id"];

        $query = "DELETE FROM posts WHERE id={$delete_id}";

        if (mysqli_query($conn, $query)) {
            header("Location: ".ROOT_URL.'');
        } else {
            echo "ERROR: ".mysqli_error($conn);
        }
    }

    $id = $_GET["id"];
    $query = "SELECT * FROM posts WHERE id={$id}";
    $result = mysqli_query($conn, $query);
    $blog = mysqli_fetch_assoc($result);

    mysqli_free_result($result);
    mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once("header.php"); ?>
    <title><?php echo $blog["title"] ?></title>

    <style>
        input[type=submit], input[type=button] {
            position: relative;
            right: 30px;
            background-color: white;
            border-style: solid;
            border-color: #122b40;
            color: #122b40;
            padding: 16px 90px;
            text-decoration: none;
            margin: 4px 2px;
            cursor: pointer;
            font-family: 'Open Sans','Helvetica Neue',Helvetica,Arial,sans-serif;
        }
        input[type=submit]:hover, input[type=button]:hover{
            background-color: #122b40;
            color:white;
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <?php include_once("menu.php"); ?>

    <!-- Page Header -->
    <header class="intro-header" style="background-image: url('<?php echo $blog["image"] ?>')">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                    <div class="site-heading">
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                    <div class="post-preview">
                        <!--<img src="https://nypost.com/wp-content/uploads/sites/2/2019/03/190309-nyc-bankrupt.jpg?quality=80&strip=all" alt="alternatetext" width="100%" height="200">-->
                        <h1 style="display: inline-block" href="post.php"class="post-title">
                            <?php echo $blog["title"] ?>
                        </h1>

                        <p style="font-size: 22px; margin-top: 30px; margin-bottom: 10px"><?php echo $blog["text"] ?></p>

                        <p class="post-meta">Posted by <?php echo $blog["author"] ?> on <?php echo $blog["created_on"] ?></p>
                        <hr>

                        <input type="button" style="float: left"  onclick="location.href='editpost.php?id=<?php echo $blog["id"] ?>'" value="Edit" />

                        <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="POST">
                            <input type="hidden" name="delete_id" value="<?php echo $blog["id"] ?>">
                            <input style="float: right" type="submit" value="Delete" name="delete">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <hr>
    <!-- Footer -->
    <?php include_once("footer.php"); ?>
</body>
</html>
