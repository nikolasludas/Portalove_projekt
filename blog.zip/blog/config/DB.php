<?php
    require "config.php";
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

     if(mysqli_connect_errno()){
         // if connection fails
         echo "Failed to connect to the database".mysqli_connect_errno();
     }
?>
